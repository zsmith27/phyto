optimal.cutpoints <-
function(X, ...) {
		UseMethod("optimal.cutpoints")
}
