sm <- function(x) suppressMessages(x)
