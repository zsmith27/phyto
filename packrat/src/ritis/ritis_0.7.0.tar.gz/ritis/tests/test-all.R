library("testthat")
test_check("ritis")
